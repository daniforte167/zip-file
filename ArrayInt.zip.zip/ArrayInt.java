import java.util.Arrays;

public class ArrayInt {
    
    public static int[] copy(int [] array){
        int [] CopyofArray = new int[array.length];
        for (int i=0; i< array.length; i++){
            //setting new array to the same index of the array
            CopyofArray[i] = array [i];
        }
        System.out.println("New, Duplicated Array: " + Arrays.toString(CopyofArray));
        return CopyofArray;
    }

    public static int addAll(int [] array){
        int sum = 0;
        for (int i = 0; i<array.length; i++){
            sum = sum + array[i];
            }
        System.out.println("The sum is: " + sum);
        return sum;
    }
        

    public static int [] addArrays(int [] array, int [] array2){
        int [] sumArray = new int[array.length];
        int Array1Num;
        int Array2Num;
        int sum;
        for (int i=0; i<array.length; i++){
            Array1Num = array [i];
            Array2Num = array2 [i];
            sum = Array1Num + Array2Num;
            sumArray[i] = sum;

        }
        System.out.println("Sum Array:" + Arrays.toString(sumArray));
        return sumArray;
    }
    
    public static int [] multiplyAll(int [] array){
        int product = 0;
        for (int i = 0; i<array.length; i++){
            product = product * array[i];
            }
        System.out.println("The product of array is: " + product);
        return array;
    }

    public static int findAverage(int [] array){
        int sumForaverage = 0;
        int average = 0;
        for (int i = 0; i<array.length; i++){
            sumForaverage = sumForaverage + array[i];
            average = sumForaverage / array.length;
            }
        System.out.println("The Average is: " + average);
        return average;
    }

    // public static int [] swap(int [] array, int x, int y){
    //     int z = array[x]; // set variable equal to a random integer in the array
    //     z = array[x];
    //     array[x] = array[y];
    //     array[y] = z;

    //     System.out.println("The Swapped " );
        
    // }

    
    public static boolean isElement(int [] array, int value){
        for(int i=0; i < array.length; i++){
            if(array[i] == value){
                return true;
            }
        }
        return false;
    }

    public static int [] reverse(int [] array){
        int [] reverseArray = new int[array.length];
        int reverseElement = 0; //starts at 0, and  then will add one in the code so that while it' going down from the last value in the array, it's adding it to said array and going up
        for(int i=0; i < array.length; i++){ //i=array.length-1 because we need it to start at our actual max index, otherwise it's trying to do it where it doesn't exisst
            reverseElement  = array.length - 1 - i; //it'll go down one in the index/array till it gets to the end 
            reverseArray[reverseElement] = array[i];
        }
        System.out.println("The Reverse Array is: " + Arrays.toString(reverseArray));
        return array;
    }

    public static int [] intersection(int [] array, int [] array2){
        int [] intersectArray = new int [array.length];
        int arrayvalue;
        for (int i = 0; i < array.length; i++){
            arrayvalue = array[i];
            for (int k = 0; k < array2.length; i++){
                if (isElement(array2, arrayvalue) &! isElement(intersectArray, arrayvalue)){
                    intersectArray[i] = arrayvalue;
                }
            }
        }
        System.out.println("The Intersection Array: " + Arrays.toString(intersectArray));
        return intersectArray;
    }


  //  public static void testAddAll(){
    //    int[] testArray = makeRandomarray(3, 10);
      //  System.out.println("2. ==== Testing: multiplyAll =====");
        //System.out.print("Input array: ");
        //System.out.println(array.ToString)

    //}



    public static void test_copy(){
        System.out.println("\n===== Starting Tester Code, copy() ======");
        int [] testingArray = {1, 2, 3, 4};
        System.out.println("TestingArray Values: " + Arrays.toString(testingArray));
        System.out.println("Expected value: new Array with values 1, 2, 3, 4");
        System.out.println("Given result: " + Arrays.toString(copy(testingArray)));
        System.out.println("===== Ending Tester Code, copy() ===== \n");
    }

    public static void test_addAll(){
        System.out.println("\n===== Starting Tester Code, addAll() ======");
        int [] testingArray = {1, 2, 3, 4};
        System.out.println("TestingArray Values: " + Arrays.toString(testingArray));
        System.out.println("Expected value: 10");
        System.out.println("Given result: " + Arrays.toString(copy(testingArray)));
        System.out.println("===== Ending Tester Code, addAll() ===== \n");
    }

    public static void test_addArray(){
        System.out.println("\n===== Starting Tester Code, addArray() ======");
        int [] testingArray = {1, 2, 3, 4, 5};
        int [] testingArray2 = {6, 7, 8, 9, 10};
        System.out.println("TestingArray Values: " + Arrays.toString(testingArray));
        System.out.println("TestingArray Values: " + Arrays.toString(testingArray2));
        System.out.println("Expected value: New Array = {7, 9, 11, 13, 15");
        System.out.println("Given result: " + Arrays.toString(copy(testingArray)));
        System.out.println("===== Ending Tester Code, addArray() ===== \n");
    }

    public static void test_multiplyAll(){
        System.out.println("\n===== Starting Tester Code, multiplyAll() ======");
        int [] testingArray = {1, 2, 3, 4, 5};
        System.out.println("TestingArray Values: " + Arrays.toString(testingArray));
        System.out.println("Expected value: 120");
        System.out.println("Given result: " + Arrays.toString(copy(testingArray)));
        System.out.println("===== Ending Tester Code, multiplyAll() ===== \n");
    }

    //tester for isElemennt
    public static void test_isElement(){
        System.out.println("\n===== Starting Tester Code isElement() =====");
        int [] testingArray = {1, 2, 3, 4, 100};
        int value = testingArray[testingArray.length - 1]; //selecting an element from the array
        System.out.println("Testing isElement with value:" + value);
        System.out.println("Result: " + isElement(testingArray, value));//Expected to return true
    
        value = 100;
        System.out.println("Testing isElement with value:" + value);
        System.out.println("Result: " + isElement(testingArray, value));//Expected to return true
        System.out.println("===== Ending Tester Code isElement() =====\n");
    }
    

    //main
    public static void main(String[] args){       
     //creating and initializing an input array for testing
        int [] array = {3, 4, 5, 12, 87, 31, 56, 32, 29, 0, 4, 5, 6, 7};
        //Printing the array
        System.out.println("Array for testing: " + Arrays.toString(array));
        copy(array);
        // addAll(array);
        // addArrays(array, array);
        // multiplyAll(array);
        // findAverage(array);
        // reverse(array);
        // intersection(array, array);

        test_copy();
        test_addAll();
        test_addArray();
        test_multiplyAll();
        test_isElement();
    
    }

}
